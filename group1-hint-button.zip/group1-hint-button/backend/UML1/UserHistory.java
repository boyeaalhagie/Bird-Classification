package UML1;


/**
 * @author goetschm
 * @version 1.0
 * @created 07-Feb-2024 2:46:44 PM
 */
public class UserHistory extends History {

	public UserHistory(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	public void getStatistics(){

	}

	public void load(){

	}

	public void save(){

	}

}