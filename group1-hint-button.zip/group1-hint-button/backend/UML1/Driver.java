package UML1;


/**
 * @author goetschm
 * @version 1.0
 * @created 07-Feb-2024 2:46:44 PM
 */
public class Driver {

	public Driver(){

	}

	public void finalize() throws Throwable {

	}

	public void main(){

	}

}