package UML1;


/**
 * @author goetschm
 * @version 1.0
 * @created 07-Feb-2024 2:46:44 PM
 */
public class Game {

	/**
	 * @author goetschm
	 * @version 1.0
	 * @created 07-Feb-2024 2:46:44 PM
	 */
	public class ain {

		public ain(){

		}

		public void finalize() throws Throwable {

		}

	}

	private String currentWord;
	private List<String> guesses;
	private List<char> lettersUsed;
	private int numGuesses;

	public Game(){

	}

	public void finalize() throws Throwable {

	}

	public int getGuessesLeft(){
		return 0;
	}

	/**
	 * 
	 * @param word
	 */
	public List<char> guess(String word){
		return null;
	}

}