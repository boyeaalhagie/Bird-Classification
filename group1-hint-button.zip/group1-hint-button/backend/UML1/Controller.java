package UML1;


/**
 * @author goetschm
 * @version 1.0
 * @created 07-Feb-2024 2:46:44 PM
 */
public class Controller {

	public LoginView m_LoginView;
	public MenuView m_MenuView;
	public GameView m_GameView;
	public Game m_Game;
	public Dictionary m_Dictionary;
	public User m_User;
	public History m_History;

	public Controller(){

	}

	public void finalize() throws Throwable {

	}

	public void guessWord(){

	}

	public void hint(){

	}

	/**
	 * 
	 * @param file
	 */
	public void loadHistory(File file){

	}

	public void setVocab(){

	}

	public void showStatistics(){

	}

	/**
	 * 
	 * @param wordList
	 */
	public void testGame(List<String> wordList){

	}

	public void updateView(){

	}

	public void useSeedWord(){

	}

}