package UML1;


/**
 * @author goetschm
 * @version 1.0
 * @created 07-Feb-2024 2:46:44 PM
 */
public class MenuView {

	public MenuView(){

	}

	public void finalize() throws Throwable {

	}

	public void displayLoss(){

	}

	public void displayStart(){

	}

	public void displayStats(){

	}

	public void displayWin(){

	}

}