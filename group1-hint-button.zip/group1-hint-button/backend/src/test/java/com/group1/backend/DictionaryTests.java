package com.group1.backend;

import com.group1.backend.game.Dictionary;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;

class DictionaryTests {
    Dictionary dict;
    @BeforeEach
    void init(){
        dict = new Dictionary();
        ArrayList<String> testWords = new ArrayList<>();
        testWords.add("Apple");
        testWords.add("Beans");
        testWords.add("Crabs");
        testWords.add("Dorks");
        testWords.add("Evens");
        dict.changeVocab(testWords, 5);
    }

    @Test
    void changeVocab(){
        ArrayList<String> testWords = new ArrayList<>();
        testWords.add("potato");
        testWords.add("orange");
        testWords.add("greens");
        dict.changeVocab(testWords, 6);

        Assertions.assertTrue(dict.wordExists("potato"));
        Assertions.assertEquals(6, dict.getWordLength());
    }

    @Test
    void importVocab(){
        //May have to update path if list is refactored
        String path = "src/main/resources/wordList.txt";
        Assertions.assertTrue(dict.importVocab(path), "Path may be incorrect");
        Assertions.assertTrue(dict.wordExists("which"));
        Assertions.assertEquals(5, dict.getWordLength());
    }

    @Test
    void getRandomWord(){
        //Make sure getRandomWord returns different words
        //Run 100 times, nearly impossible to fail if works correct, but it is random
        String temp = dict.getRandomWord();
        boolean done = false;
        for(int i = 0; (i<100)&&!done; i++){
            String newTemp = dict.getRandomWord();
            if(!temp.equalsIgnoreCase(newTemp)){
                done = true;
            }
        }

        Assertions.assertTrue(done);
    }

    @Test
    void wordExists() {
        Assertions.assertTrue(dict.wordExists("Apple"));
        Assertions.assertTrue(dict.wordExists("Crabs"));
        Assertions.assertTrue(dict.wordExists("dorks"));
        Assertions.assertTrue(dict.wordExists("evens"));

        Assertions.assertFalse(dict.wordExists("Banan"));
        Assertions.assertFalse(dict.wordExists("Zebra"));
        Assertions.assertFalse(dict.wordExists("Grape"));

        boolean thrown = false;
        try {
            dict.wordExists("Banana");
        }catch(IllegalArgumentException e){
            thrown = true;
        }
        Assertions.assertTrue(thrown);
    }

}
