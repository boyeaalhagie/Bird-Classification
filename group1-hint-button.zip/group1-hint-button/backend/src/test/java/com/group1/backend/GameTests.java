package com.group1.backend;

import com.group1.backend.game.Dictionary;
import com.group1.backend.game.Game;
import com.group1.backend.game.LetterStatus;
import com.group1.backend.request.GuessResponse;
import com.group1.backend.user.Guest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class GameTests {

    @Test
    void guessIncorrect() {
        String path = "src/main/resources/wordList.txt";
        Dictionary.importVocab(path);

        Game game = new Game(new Guest(), "tiers");
        GuessResponse response = game.guess("tests");
        Assertions.assertTrue(response.isValid);
        Assertions.assertFalse(response.isGameEnd);
        Assertions.assertSame(response.letterStatuses.get(0).getAccuracy(), LetterStatus.Accuracy.CORRECT);
        Assertions.assertSame(response.letterStatuses.get(1).getAccuracy(), LetterStatus.Accuracy.MISPLACED);
        Assertions.assertSame(response.letterStatuses.get(2).getAccuracy(), LetterStatus.Accuracy.MISPLACED);
        Assertions.assertSame(response.letterStatuses.get(3).getAccuracy(), LetterStatus.Accuracy.MISPLACED);
        Assertions.assertSame(response.letterStatuses.get(4).getAccuracy(), LetterStatus.Accuracy.CORRECT);

        response = game.guess("badly");
        Assertions.assertTrue(response.isValid);
        Assertions.assertFalse(response.isGameEnd);
        Assertions.assertSame(response.letterStatuses.get(0).getAccuracy(), LetterStatus.Accuracy.WRONG);
        Assertions.assertSame(response.letterStatuses.get(1).getAccuracy(), LetterStatus.Accuracy.WRONG);
        Assertions.assertSame(response.letterStatuses.get(2).getAccuracy(), LetterStatus.Accuracy.WRONG);
        Assertions.assertSame(response.letterStatuses.get(3).getAccuracy(), LetterStatus.Accuracy.WRONG);
        Assertions.assertSame(response.letterStatuses.get(4).getAccuracy(), LetterStatus.Accuracy.WRONG);

        response = game.guess("board");
        Assertions.assertTrue(response.isValid);
        Assertions.assertFalse(response.isGameEnd);
        Assertions.assertSame(response.letterStatuses.get(0).getAccuracy(), LetterStatus.Accuracy.WRONG);
        Assertions.assertSame(response.letterStatuses.get(1).getAccuracy(), LetterStatus.Accuracy.WRONG);
        Assertions.assertSame(response.letterStatuses.get(2).getAccuracy(), LetterStatus.Accuracy.WRONG);
        Assertions.assertSame(response.letterStatuses.get(3).getAccuracy(), LetterStatus.Accuracy.CORRECT);
        Assertions.assertSame(response.letterStatuses.get(4).getAccuracy(), LetterStatus.Accuracy.WRONG);

        response = game.guess("tales");
        Assertions.assertTrue(response.isValid);
        Assertions.assertFalse(response.isGameEnd);

        response = game.guess("bread");
        Assertions.assertTrue(response.isValid);
        Assertions.assertFalse(response.isGameEnd);

        response = game.guess("nails");
        Assertions.assertTrue(response.isValid);
        Assertions.assertTrue(response.isGameEnd);
    }

    @Test
    void guessInvalid() {
        String path = "src/main/resources/wordList.txt";
        Dictionary.importVocab(path);

        Game game = new Game(new Guest(), "tiers");
        GuessResponse response = game.guess("testser");
        Assertions.assertFalse(response.isValid);
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("tierstest");
        Assertions.assertFalse(response.isValid);
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("ti3rs");
        Assertions.assertFalse(response.isValid);
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("ñetes");
        Assertions.assertFalse(response.isValid);
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("tests");
        Assertions.assertTrue(response.isValid);
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("tests");
        Assertions.assertFalse(response.isValid);
        Assertions.assertFalse(response.isGameEnd);
    }

    @Test
    void guessCorrect() {
        String path = "src/main/resources/wordList.txt";
        Dictionary.importVocab(path);

        Game game = new Game(new Guest(), "tiers");
        GuessResponse response = game.guess("tiers");
        Assertions.assertTrue(response.isValid);
        Assertions.assertTrue(response.isGameEnd);
        Assertions.assertSame(response.letterStatuses.get(0).getAccuracy(), LetterStatus.Accuracy.CORRECT);
        Assertions.assertSame(response.letterStatuses.get(1).getAccuracy(), LetterStatus.Accuracy.CORRECT);
        Assertions.assertSame(response.letterStatuses.get(2).getAccuracy(), LetterStatus.Accuracy.CORRECT);
        Assertions.assertSame(response.letterStatuses.get(3).getAccuracy(), LetterStatus.Accuracy.CORRECT);
        Assertions.assertSame(response.letterStatuses.get(4).getAccuracy(), LetterStatus.Accuracy.CORRECT);

        game = new Game(new Guest(), "tiers");
        response = game.guess("tests"); // Valid word, guess 1
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("tester"); // Invalid word, no guess used
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("rates"); // Valid word, guess 2
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("break"); // Valid word, guess 3
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("hurls"); // Valid word, guess 4
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("rolls"); // Valid word, guess 5
        Assertions.assertFalse(response.isGameEnd);
        response = game.guess("tiers"); // Valid word, guess 6 - last guess
        Assertions.assertTrue(response.isValid);
        Assertions.assertTrue(response.isGameEnd);
    }
}
