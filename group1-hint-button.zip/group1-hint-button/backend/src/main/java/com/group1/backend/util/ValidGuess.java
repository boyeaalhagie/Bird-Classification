package com.group1.backend.util;

import com.group1.backend.game.LetterStatus;

import java.util.ArrayList;


public class ValidGuess {
    private int length;
    private LetterStatus[] letters;

    private String word;

    public ValidGuess(String word, ArrayList<LetterStatus> letterStatuses) {
        this.word = word;
        letters = letterStatuses.toArray(new LetterStatus[0]);
    }

    public int length() {
        return length;
    }

    public LetterStatus getLetter(int index) {
        if (index < 0 || index >= length) {
            throw new IndexOutOfBoundsException(index);
        }

        return letters[index];
    }

    public String getWord() {
        return word;
    }
}
