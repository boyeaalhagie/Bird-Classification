package com.group1.backend.request;

import com.group1.backend.controller.WordleController;

/**
 * {@link WordleController} listens for this at
 * {@link WordleController#initGame(InitGameRequest) initGame}
 */
public class InitGameRequest extends BaseRequest {

}
