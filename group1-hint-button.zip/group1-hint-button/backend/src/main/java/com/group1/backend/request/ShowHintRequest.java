package com.group1.backend.request;

import com.group1.backend.controller.WordleController;

/**
 * {@link WordleController} listens for this at
 * {@link WordleController#getHint(ShowHintRequest) handleGuess}
 */
public class ShowHintRequest extends BaseRequest {

}
