package com.group1.backend.game;

public class LetterStatus {
    private final char letter;
    private final Accuracy accuracy;

    @Deprecated
    public static LetterStatus dummyStatus() {
        return new LetterStatus('h', Accuracy.WRONG);
    }

    public LetterStatus(char letter, Accuracy accuracy) {
        this.letter = letter;
        this.accuracy = accuracy;
    }

    public char getLetter() {
        return letter;
    }

    public Accuracy getAccuracy() {
        return accuracy;
    }

    public enum Accuracy {
        WRONG,
        MISPLACED,
        CORRECT,
    }
}
