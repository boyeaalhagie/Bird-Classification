package com.group1.backend.request;

import com.group1.backend.user.User;

public class BaseRequest {
    private User user;

    public User getUser() {
        return user;
    }
}
