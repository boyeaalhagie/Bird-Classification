package com.group1.backend.request;

import com.group1.backend.user.User;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;

public class LoginResponse {
    public boolean success;

    public @Nullable User user;

    public static LoginResponse success(@NonNull User user) {
        return new LoginResponse(user, true);
    }

    public static LoginResponse failure() {
        return new LoginResponse(null, false);
    }

    public LoginResponse() {}

    private LoginResponse(@Nullable User user, boolean success) {
        this.success = success;
        this.user = user;
    }
}
