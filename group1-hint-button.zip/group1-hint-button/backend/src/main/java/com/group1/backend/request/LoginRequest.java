package com.group1.backend.request;

import org.springframework.lang.Nullable;

public class LoginRequest {
    private boolean isGuest;
    private @Nullable String username;

    public boolean isGuest() {
        return isGuest;
    }

    @Nullable
    public String getUsername() {
        return username;
    }
}
