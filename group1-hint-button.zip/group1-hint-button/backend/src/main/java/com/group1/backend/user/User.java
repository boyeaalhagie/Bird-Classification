package com.group1.backend.user;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        property = "type"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Guest.class, name = "Guest"),
        @JsonSubTypes.Type(value = NamedUser.class, name = "NamedUser")
})
public interface User {
    String getUserId();
    String getDisplayName();
    boolean equals(Object obj);
    int hashCode();
}
