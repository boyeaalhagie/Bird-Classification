package com.group1.backend.request;

import com.group1.backend.controller.WordleController;
import com.group1.backend.game.Game;
import com.group1.backend.util.ValidGuess;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link WordleController} returns this upon receiving an {@link ShowHintRequest}
 * at {@link WordleController#getHint(ShowHintRequest) initGame}
 */
public class ShowHintResponse {
    public String hint;


    public ShowHintResponse(String hint) {
        this.hint = hint;
    }



}
