package com.group1.backend.history;

import com.group1.backend.database.Database;
import com.group1.backend.game.Game;
import com.group1.backend.request.LoginResponse;
import com.group1.backend.user.NamedUser;
import com.group1.backend.user.User;
import com.group1.backend.util.Util;
import com.group1.backend.util.ValidGuess;

import java.sql.*;
import java.util.List;

public class History {
    private final Database database;

    public History(Database database) {
        this.database = database;
        this.initDatabase();
    }

    private void initDatabase() {
        Statement statement = database.getStatement();
        try {
            statement.executeUpdate(
                    "CREATE TABLE IF NOT EXISTS user2past_games (" +
                            "user_id VARCHAR(36)," +
                            "past_games INTEGER ARRAY" +
                    ");"
            );

            statement.executeUpdate(
                    "CREATE TABLE IF NOT EXISTS past_games (" +
                            "game_id INTEGER AUTO_INCREMENT," +
                            "user_id VARCHAR(36)," +
                            "reference_word VARCHAR(10)," +
                            "guesses VARCHAR(10) ARRAY[6]" +
                    ");"
            );
        } catch (SQLException e) {
            System.out.println("Could not initialize database tables!" + e.getMessage());
        }
    }

    public void addGame(Game game) {
        int gameId = add_game_to_past_games(game);
        if (gameId < 0) return;

        insert_if_absent(game.getUser());

        add_past_game_to_user(game.getUser(), gameId);
    }

    /**
     *
     * @return the game id if it was successful, -1 otherwise.
     */
    private int add_game_to_past_games(Game game) {
        int gameId = -1;
        try (PreparedStatement stmt = database.getConnection().prepareStatement(
                "INSERT INTO past_games (user_id, reference_word, guesses) VALUES (" +
                        "?, " + // game_id
                        "?, " + // user_id
                        "ARRAY [?, ?, ?, ?, ? ,?]" + // guesses
                ");"
        )) {
            stmt.setString(1, game.getUser().getUserId());
            stmt.setString(2, game.getCorrectWord());

            List<String> guesses = game.getGuesses().stream().map(ValidGuess::getWord).toList();

            for (int i = 0; i < 6; i++) {
                int paramIndex = i + 3;

                if (i < guesses.size()) {
                    stmt.setString(paramIndex, guesses.get(i));
                } else {
                    stmt.setNull(paramIndex, Types.VARCHAR);
                }
            }

            stmt.executeUpdate();

            ResultSet generated = stmt.getGeneratedKeys();
            generated.next();
            gameId = generated.getInt("game_id");
        } catch (SQLException e) {
            System.out.println("Failed to add game!" + e.getMessage());
        }

        return gameId;
    }

    // Insert a new array for the user if they don't have one
    private void insert_if_absent(User user) {
        try (PreparedStatement stmt = database.getConnection().prepareStatement(
                "INSERT INTO user2past_games SELECT * FROM (" +
                        "SELECT ?, ARRAY []" +
                ") x WHERE NOT EXISTS(SELECT * FROM user2past_games);"
        )) {
            stmt.setString(1, user.getUserId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Failed to associate completed game with user!" + e.getMessage());
        }
    }

    private void add_past_game_to_user(User user, int gameId) {
        try (PreparedStatement stmt = database.getConnection().prepareStatement(
                "SELECT ARRAY_APPEND(past_games, ?) FROM user2past_games WHERE user_id = ?"
        )) {
            stmt.setInt(1, gameId);
            stmt.setString(2, user.getUserId());
            ResultSet res = stmt.executeQuery();

            if (!res.next()) throw new SQLException("Did not create new row for user!");
            if (res.next()) throw new IllegalStateException("Duplicate users in user2past_games table!");
        } catch (SQLException e) {
            System.out.println("Failed to associate completed game with user!" + e.getMessage());
        }
    }
}
