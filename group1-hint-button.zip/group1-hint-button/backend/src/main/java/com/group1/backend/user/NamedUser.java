package com.group1.backend.user;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class NamedUser implements User {
    private final @JsonProperty("username") String username;

    // This is necessary for some reason.
    // https://stackoverflow.com/questions/69538090
    public NamedUser() {
        username = null;
    }

    // Currently, username MUST be unique.
    public NamedUser(String username) {
        this.username = username;
    }

    @Override
    public String getUserId() {
        return username;
    }

    @Override
    public String getDisplayName() {
        return username;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NamedUser namedUser = (NamedUser) o;

        return Objects.equals(username, namedUser.username);
    }

    @Override
    public int hashCode() {
        return username != null ? username.hashCode() : 0;
    }
}
