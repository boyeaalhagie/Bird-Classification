package com.group1.backend.request;

import com.group1.backend.controller.WordleController;
import com.group1.backend.game.Game;
import com.group1.backend.util.ValidGuess;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link WordleController} returns this upon receiving an {@link InitGameRequest}
 * at {@link WordleController#initGame(InitGameRequest) initGame}
 */
public class InitGameResponse {
    public int wordLength;
    public List<ValidGuess> prevGuesses;
    
    public InitGameResponse(int wordLength, List<ValidGuess> prevGuesses) {
        this.wordLength = wordLength;
        this.prevGuesses = prevGuesses;
    }

    public static InitGameResponse fromGame(Game game) {
        return new InitGameResponse(
                game.getCorrectWord().length(),
                game.getGuesses()
        );
    }

    public static InitGameResponse newGame(int wordLength) {
        return new InitGameResponse(wordLength, new ArrayList<>());
    }

    public static InitGameResponse inProgressGame(
            int wordLength, List<ValidGuess> prevGuesses) {
        return new InitGameResponse(wordLength, prevGuesses);
    }
}
