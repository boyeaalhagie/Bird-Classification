package com.group1.backend.controller;

import com.group1.backend.game.Dictionary;
import com.group1.backend.game.Game;
import com.group1.backend.user.User;

import java.util.HashMap;
import java.util.Map;

public class GameManager {
    private final Map<User, Game> games;

    public GameManager() {
        this.games = new HashMap<>();
    }

    public Game newGame(User user) {
        return new Game(user, Dictionary.getRandomWord());
    }

    public Game getGame(User user) {
        return this.games.computeIfAbsent(user, this::newGame);
    }
}
