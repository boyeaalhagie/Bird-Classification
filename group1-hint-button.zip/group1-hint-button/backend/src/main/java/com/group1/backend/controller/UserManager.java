package com.group1.backend.controller;

import com.group1.backend.database.Database;
import com.group1.backend.request.LoginRequest;
import com.group1.backend.request.LoginResponse;
import com.group1.backend.user.Guest;
import com.group1.backend.user.NamedUser;
import com.group1.backend.util.Util;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserManager {
    private final Database database;

    public UserManager(Database database) {
        this.database = database;
        this.initDatabase(database);
    }

    private void initDatabase(Database database) {
        Statement statement = database.getStatement();
        try {
            statement.executeUpdate(
                    "CREATE TABLE IF NOT EXISTS usernames (" +
                        "username VARCHAR(32)" +
                    ");"
            );
        } catch (SQLException e) {
            System.out.println("Could not initialize database tables!" + e.getMessage());
        }
    }

    public LoginResponse handleLogin(LoginRequest request) {
        if (request.isGuest()) {
            return LoginResponse.success(new Guest());
        } else {
            try (PreparedStatement stmt = database.getConnection().prepareStatement(
                    "SELECT * FROM usernames WHERE username = ?"
            )) {
                Util.fillStatement(stmt, request.getUsername());
                ResultSet result = stmt.executeQuery();

                // The ResultSet isn't empty
                if (result.next()) {
                    if (result.next()) throw new IllegalStateException(
                            "Two users exist with the same username: " + request.getUsername()
                    );

                    return LoginResponse.success(new NamedUser(request.getUsername()));
                }
            } catch (SQLException ignored) { /* Maybe return an error instead? */ }
        }

        return LoginResponse.failure();
    }
}
