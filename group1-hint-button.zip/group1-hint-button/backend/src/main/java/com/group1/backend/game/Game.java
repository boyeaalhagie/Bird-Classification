package com.group1.backend.game;

import com.group1.backend.request.GuessResponse;
import com.group1.backend.user.User;
import com.group1.backend.util.ValidGuess;

import java.util.ArrayList;
import java.util.List;

public class Game {
    public static final int MAX_GUESSES = 6;

    private User user;

    private final String correctWord;
    private List<ValidGuess> guesses;
    private List<Character> lettersUsed;
    private int numGuesses;

    public Game(User user, String correctWord) {
        this.user = user;
        this.correctWord = correctWord;
        this.lettersUsed = new ArrayList<>(26);
        this.guesses = new ArrayList<>();
    }

    public int getGuessesLeft() {
        return MAX_GUESSES - numGuesses;
    }

    /**
     * @param word The word submitted by the user
     * @return A single GuessResponse indicating the status of the submitted word
     */
    public GuessResponse guess(String word) {
        this.numGuesses++;
        word = word.toLowerCase();
        ArrayList<LetterStatus> letterStatuses = new ArrayList<>();

        if (!isValidGuess(word)) {
            numGuesses--;
            return GuessResponse.invalid(numGuesses);
        }


        if (word.equals(correctWord)) {
            for (int i = 0; i < correctWord.length(); i++) {
                letterStatuses.add(new LetterStatus(word.charAt(i), LetterStatus.Accuracy.CORRECT));
            }
            guesses.add(new ValidGuess(word, letterStatuses));
            return GuessResponse.correct(numGuesses, letterStatuses);
        }

        for (int i = 0; i < correctWord.length(); i++) {
            char letter = word.charAt(i);
            lettersUsed.add(letter);
            if (letter == correctWord.charAt(i)) {
                letterStatuses.add(new LetterStatus(letter, LetterStatus.Accuracy.CORRECT));
            } else {
                for (int j = 0; j < correctWord.length(); j++) {
                    if (letter == correctWord.charAt(j) && letterStatuses.size() <= i) {
                        letterStatuses.add(new LetterStatus(letter, LetterStatus.Accuracy.MISPLACED));
                    }
                }
            }
            if (letterStatuses.size() <= i) {
                letterStatuses.add(new LetterStatus(letter, LetterStatus.Accuracy.WRONG));
            }
        }

        if (numGuesses == MAX_GUESSES) {
            guesses.add(new ValidGuess(word, letterStatuses));
            return GuessResponse.lastIncorrect(numGuesses, letterStatuses);
        }

        guesses.add(new ValidGuess(word, letterStatuses));
        return GuessResponse.validIncorrect(numGuesses, letterStatuses);
    }

    public String getCorrectWord() {
        return this.correctWord;
    }

    public List<ValidGuess> getGuesses() {
        return this.guesses;
    }

    public User getUser() {
        return user;
    }

    private boolean isValidGuess(String word) {
        for (ValidGuess guess : guesses) {
            if (guess.getWord().equals(word)) {
                return false;
            }
        }
        try {
            if (!Dictionary.wordExists(word)) {
                return false;
            }
        } catch (IllegalArgumentException e) {
            return false;
        }

        return true;
    }
}
