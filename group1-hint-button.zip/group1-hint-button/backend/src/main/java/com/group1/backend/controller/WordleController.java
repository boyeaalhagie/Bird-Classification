package com.group1.backend.controller;
import com.group1.backend.request.ShowHintRequest;
import com.group1.backend.database.Database;
import com.group1.backend.game.Dictionary;
import com.group1.backend.game.Game;
import com.group1.backend.history.History;
import com.group1.backend.request.*;
import com.group1.backend.util.JsonPostMapping;
import jakarta.annotation.PreDestroy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLException;

@RestController
public class WordleController {
    private final GameManager gameManager;
    private final UserManager userManager;
    private final History history;
    private final Database database;

    public WordleController() throws SQLException {
        this.database = new Database();
        this.gameManager = new GameManager();
        this.userManager = new UserManager(this.database);
        this.history = new History(this.database);
        Dictionary.importVocab("src/main/resources/wordList.txt");
    }

    // Navigating to http://localhost:8080/hello-world while the backend is running
    // will give you "Hello World!" and print "Hello!" in the console.
    @GetMapping("/hello-world")
    public String helloWorld() {
        System.out.println("Hello!");
        return "Hello World!";
    }

    @JsonPostMapping("login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        return httpCreatedEntity(this.userManager.handleLogin(request));
    }

    @JsonPostMapping("init-game")
    public ResponseEntity<InitGameResponse> initGame(@RequestBody InitGameRequest request) {
        Game game = gameManager.getGame(request.getUser());
        return httpCreatedEntity(InitGameResponse.fromGame(game));

    }



    @JsonPostMapping("get-hint") // Change to @PostMapping
    public ResponseEntity<ShowHintResponse> getHint(@RequestBody ShowHintRequest request) {
        Game game = gameManager.getGame(request.getUser());
        String hint = game.getCorrectWord();
        return httpCreatedEntity(new ShowHintResponse(hint));
    }

    @GetMapping(value = "word")
    public String getWord() {
        return "hello";
    }

    @JsonPostMapping("guess")
    public ResponseEntity<GuessResponse> handleGuess(@RequestBody GuessRequest guessRequest) {
        Game game = gameManager.getGame(guessRequest.getUser());
        GuessResponse response = game.guess(guessRequest.getWord());

        if (response.isGameEnd) {
            history.addGame(game);
        }

        return httpCreatedEntity(response);
    }

    @JsonPostMapping("wordchange")
    public void handleWordChange(@RequestBody ChangeListRequest changeListRequest) {
        //TODO: Validate user is admin before replacing words
        if(changeListRequest.getWordList() != null){
            Dictionary.changeVocab(changeListRequest.getWordList());
        }
    }

    @PreDestroy
    public void close() throws SQLException {
        this.database.close();
    }

    private <T> ResponseEntity<T> httpCreatedEntity(T body) {
        return new ResponseEntity<>(body, HttpStatus.CREATED);
    }
}
