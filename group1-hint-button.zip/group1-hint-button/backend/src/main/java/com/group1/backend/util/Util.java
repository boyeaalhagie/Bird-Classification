package com.group1.backend.util;

import java.sql.Array;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class Util {
    public static void fillStatement(PreparedStatement stmt, String... params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            stmt.setString(i+1, params[i]);
        }
    }
}
