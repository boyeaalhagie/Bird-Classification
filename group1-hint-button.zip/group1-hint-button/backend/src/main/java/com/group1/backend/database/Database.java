package com.group1.backend.database;

import java.sql.*;

public class Database implements AutoCloseable {
    private static final String DB_PATH = "./src/main/resources/backend";
    private final Connection connection;
    private final Statement statement;

    public Database() throws SQLException {
        try {
            Class.forName("org.h2.Driver");
            this.connection = DriverManager.getConnection("jdbc:h2:" + DB_PATH);
            this.statement = connection.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            throw new SQLException("Could not connect to database!" + e.getMessage());
        }
    }

    public Statement getStatement() {
        return statement;
    }

    public Connection getConnection() {
        return connection;
    }

    @Override
    public void close() throws SQLException {
        this.statement.close();
        this.connection.close();
    }
}
