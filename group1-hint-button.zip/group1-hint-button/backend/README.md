# Getting Started

This project uses [Spring Boot](https://spring.io/projects/spring-boot).

Opening this `backend` folder in IntelliJ will automatically download the necessary dependencies.

## Running the backend

In addition to downloading dependencies, IntelliJ should generate a run configuration.

## `BackendDriver`

Use this run configuration to start the backend. The backend should be hosted at https://localhost:8080.

Try navigating to [/hello-world](https://localhost:8080/hello-world). You should see a blank webpage with the text, "Hello World!". 
The code for this endpoint is located **[here](src/main/java/com/group1/backend/controller/WordleController.java)**.

## Learn More

[Spring Boot](https://spring.io/projects/spring-boot) itself has several good learning resources on its website.

In addition, I found [this tutorial](https://milanwittpohl.com/projects/tutorials/Full-Stack-Web-App/the-backend-with-java-and-spring) to be helpful.

