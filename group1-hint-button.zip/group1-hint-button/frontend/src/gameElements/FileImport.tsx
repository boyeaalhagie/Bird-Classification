import React from "react";
import {Button, FileInput} from "@blueprintjs/core";
import {Row} from "react-bootstrap";
import {ChangeListRequest} from "../request/ChangeListRequest";
import {NamedUser} from "../request/User";

/**
 * The props for the game input
 */
interface IFileImportProps {
    disabled:boolean;
    submitChangeList: (guess:ChangeListRequest) => void;
}

/**
 * The visual representation of the game input
 * @param props the props for the game input
 */
export function FileImport(props: IFileImportProps): JSX.Element {

    const boxText:string = "";
    const buttonText:string = "Confirm";

    let file:File | null = null;

    const handleButtonPress = async (event: React.MouseEvent) => {
        if (file != null) {
            let words_raw: string;
            words_raw = await file.text();
            let words: string[];

            //TODO: Replace users with current user
            if (file.name.endsWith(".txt")) {
                words = words_raw.split("\n")
                props.submitChangeList(new ChangeListRequest(new NamedUser("dummy"), words));
            }else if(file.name.endsWith(".csv")){
                words = words_raw.split(",")
                props.submitChangeList(new ChangeListRequest(new NamedUser("dummy"), words));
            }
        }

    }

    const handleFileChoose: React.FormEventHandler<HTMLInputElement>  = (event) => {
        let temp = event.currentTarget.files
        if (temp == null){
            file = null
        }else{
            file = temp.item(0)
        }
    }

    /**
     * The visual representation of the file import (returned element)
     *
     */
    return (
        <div>
            <Row>
                <p>Change Vocab File</p>
                <FileInput
                    text={boxText}
                    disabled={props.disabled}
                    fill={false}
                    onInputChange = {(event: React.FormEvent<HTMLInputElement>) => handleFileChoose(event)}
                />
                <Button
                    text={buttonText}
                    minimal = {false}
                    onClick = {handleButtonPress}
                    disabled = {false}
                />
            </Row>
        </div>
        )

}
