import React, { createRef } from "react";
import axios from "axios";
import { Container, Row, Button, Modal,} from "react-bootstrap";
import { GuessRequest } from "../request/GuessRequest";
import { GuessResponse } from "../request/GuessResponse";
import { Grid } from "./Grid";
import { NamedUser } from "../request/User";
import { FileImport } from "./FileImport";
import { ChangeListRequest } from "../request/ChangeListRequest";
import {Accuracy, LetterStatus} from "../request/LetterStatus";
import {ShowHintRequest} from "../request/ShowHintRequest";
import {ShowHintResponse} from "../request/ShowHintResponse";

/**
 * The states for visual representation of the game
 */



interface IGameState {
  attempts: number;
  wordLength: number;
  res: GuessResponse;
  isGameEnd: boolean;
  showHint: boolean;
  hintsUsed: number;
  hint: { index: number; letter: string };
}

interface IEmptyProps {}

/**
 * The Game component
 * It contains the header, the grid, and the modal for the how to play page.
 * It also handles the game state and the logic for submitting guesses.
 * @class
 * @param props The empty props.
 * @property {number} attempts The number of attempts made by the user.
 * @property {number} wordLength The length of the word to guess.
 * @property {GuessResponse} res The response from the server after submitting a guess.
 * @property {boolean} isGameEnd A flag indicating whether the game has ended.
 * @property {boolean} showHint A flag indicating whether the how to play page is displayed.
 * @property {function} submitGuess A function to submit a guess to the server.
 * @property {function} toggleHint A function to toggle the 'showHint' state variable.
 * @property {function} render The render function for the component.
 */
class Game extends React.Component<IEmptyProps, IGameState> {
  constructor(props: IEmptyProps) {
    super(props);
    this.state = {
      attempts: 0,
      wordLength: 5,
      res: {
        numGuesses: 0,
        isValid: false,
        isGameEnd: false,
        isCorrectWord: false,
        letterStatuses: [],
      },
      isGameEnd: false,
      showHint: false, hintsUsed: 0, hint: { index: 0, letter: "" },
    };
  }

  /**
   * Submits a guess to the server and updates the game state based on the response.
   * If the guess is invalid, it adds a shake animation to the current row.
   * If the maximum number of attempts has been reached or the guess is valid, it ends the game.
   *
   * @param word The guessed word.
   */
   submitGuess = (word: string) => {
     const guess = new GuessRequest(new NamedUser("dummy"), word);

     axios.post("http://localhost:8080/guess", guess).then((res) => {
       // Increment attempts before adding the shake animation this.setState(prevState => ({ attempts: prevState.attempts + 1}));
        this.setState({ res: GuessResponse.fromAxiosResponse(res.data) }, () => {
         // console.log("receiveGuess", res.data);
          if (!res.data.isValid) {
           const rowIndex = this.state.attempts;
           const gridRow = document.querySelector(`.grid-row:nth-child(${rowIndex})`);
           if (gridRow) {
             gridRow.classList.add('shake');
              // Remove the shake animation after a short delay
             setTimeout(() => {
               gridRow.classList.remove('shake');
             }, 1000);
             this.setState(prevState => ({ attempts: prevState.attempts}));
           }
         }

         // Check if the game should end using the updated state
         if (this.state.attempts >= 6 || res.data.isValid) {
           this.setState({ isGameEnd: true });
         }
       });
     });
   };

  /**
   * Toggles the 'showHint' state variable.
   * If 'showHint' is currently true, it will be set to false, and vice versa.
   */
  toggleModal = () => {
    this.setState((prevState) => ({
      showHint: !prevState.showHint,
    }));
  };

  /**
   * Shows a hint to the user.
   * the hint is a letter from the word to guess.
   * The user can use up to 3 hints.
   */
  showHint = () => {
      if (this.state.hintsUsed < 3) {
          this.setState((prevState) => ({ hintsUsed: prevState.hintsUsed + 1 }));
          //get the correct guess from the backend
          const hint = new ShowHintRequest(new NamedUser("dummy"));
            axios.post("http://localhost:8080/get-hint", hint).then((res) => {

                //this.setState({ hint: ShowHintResponse.fromAxiosResponse(res.data).hint });
                console.log("hint: ", ShowHintResponse.fromAxiosResponse(res.data).hint);
            });
      } else {

          alert("You've run out of hints \nHint used: " + this.state.hintsUsed + "/3");
      }
  };


  submitChangeList = (file: ChangeListRequest) => {
    axios.post("http://localhost:8080/wordchange", file);
    this.render();
  };

  /**
   * Renders the Game component.
   */
  render() {
     return (
         <>
             <div className="header">
                 {/*hint button*/}
                 <button className="hint-btn" onClick={this.showHint}>
                     <svg height="24" width="24" fill="#FFFFFF" viewBox="0 0 24 24" data-name="Layer 1" id="Layer_1"
                          className="sparkle">
                         <path
                             d="M10,21.236,6.755,14.745.264,11.5,6.755,8.255,10,1.764l3.245,6.491L19.736,11.5l-6.491,3.245ZM18,
                    21l1.5,3L21,21l3-1.5L21,18l-1.5-3L18,18l-3,1.5ZM19.333,4.667,20.5,7l1.167-2.333L24,3.5,21.667,2.333,
                    20.5,0,19.333,2.333,17,3.5Z"></path>
                     </svg>
                     <span className="text">Hint: {3 - this.state.hintsUsed} </span>
                 </button>

                 <p className={"guess-left"}>Guess left: {Math.max(0, 6 - this.state.attempts)} </p>
                 <div className="header-text"> Wordle</div>
                 <button className="how-to-play-btn" onClick={this.toggleModal}>
                     <img
                         src={require("../resources/hint.png")} alt=""
                     />
                 </button>

                 {/*modal to display the how to play page*/}
                 <div>
                     <Modal show={this.state.showHint} onHide={this.toggleModal} centered className="overlay">
                         <Modal.Header>
                             <Button className="close-modal" onClick={this.toggleModal}> Close </Button>
                         </Modal.Header>
                         <Modal.Body className="modal-content">
                             <img className={'modal-img'} src={require("../resources/how_to_play.png")} alt=""/>
                         </Modal.Body>
                     </Modal>
                 </div>

                 {/*stat button*/}
                 <button className="stat-btn">
                     <img className={'modal-img'} src={require("../resources/stat.png")} alt=""/>
                 </button>
                 {/*<div className="input-div">*/}
                 {/*    <input className="input" name="file" type="file"/>*/}
                 {/*    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" stroke-linejoin="round"*/}
                 {/*         stroke-linecap="round" viewBox="0 0 24 24" stroke-width="2" fill="none" stroke="currentColor"*/}
                 {/*         className="icon">*/}
                 {/*        <polyline points="16 16 12 12 8 16"></polyline>*/}
                 {/*        <line y2="21" x2="12" y1="12" x1="12"></line>*/}
                 {/*        <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path>*/}
                 {/*        <polyline points="16 16 12 12 8 16"></polyline>*/}
                 {/*    </svg>*/}
                 {/*</div>*/}
             </div>
             <Container>
                 <Grid
                     hint={this.state.hint}
                     submitGuess={this.submitGuess}
                     wordLength={this.state.wordLength}
                     res={this.state.res}
                     isGameEnd={this.state.isGameEnd}
                 />
               <Row>
          {/*<FileImport*/}
          {/*  disabled={false}*/}
          {/*  submitChangeList={this.submitChangeList}*/}
          {/*/>*/}
        </Row>
      </Container>
         </>
     );
  }
}

export default Game;
