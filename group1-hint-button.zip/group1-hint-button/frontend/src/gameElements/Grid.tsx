import React, {createRef, useEffect} from "react";
import {Row} from "react-bootstrap";
import {GuessResponse} from "../request/GuessResponse";
import {Accuracy} from "../request/LetterStatus";

interface IGridProps {
  submitGuess: (word: string) => void;
  wordLength: number;
  res: GuessResponse;
  isGameEnd: boolean;
  hint: { index: number; letter: string };

}

export function Grid(props: IGridProps): JSX.Element {
  const [gameOver, setGameOver] = React.useState(false);
  const [currentRow, setCurrentRow] = React.useState(0);
  const [currentCell, setCurrentCell] = React.useState(0);

  const [showModal, setShowModal] = React.useState(false);
  const [disableBackspace, setDisableBackspace] = React.useState(true);

  const inputRefs = Array.from({ length: 6 }, () =>
      Array.from({ length: 5 }, () => createRef<HTMLInputElement>())
  );

  const setInputFocus = () => {
    // set the focus to the first cell of the current row
    inputRefs[currentRow][0].current?.focus();
  };

  /**
   * Handles the key press event for the grid.
   * If the pressed key is a letter, it finds the next available input element
   * in the grid and sets its value to the pressed key.
   * @param event The key press event.
   */
  const handleKeyPress = (event: KeyboardEvent) => {
    // Handle the key press here (e.g., check for specific keys)
    console.log("Key pressed:", event.key);
    if (event.key.length === 1 && event.key.match(/[a-z]/i)) {
      // Find the next available input element
      for (let i = 0; i < inputRefs.length; i++) {
        for (let j = 0; j < inputRefs[i].length; j++) {
          const input = inputRefs[i][j].current;
          if (input && !input.value) {
            // Set the value of the input element to the pressed key
            input.value = event.key.toUpperCase();
            return;
          }
        }
      }
    }
  };

  useEffect(() => {
    setInputFocus();
    return () => {
      // Clean up the event listener when the component unmounts
      window.removeEventListener("keydown", handleKeyPress);
    };
  },[]);

  useEffect(() => {
    handleUpdate();
  }, [props.res,props.isGameEnd]);

  /**
   * Handles the update of the grid cells based on the response from the server.
   * For each letter in the response, it adds a flip animation to the corresponding grid cell.
   * After the animation ends, it changes the background color of the grid cell based on the accuracy of the letter.
   */
  const handleUpdate = () => {
    if (props.res && props.res.letterStatuses) {
      const { letterStatuses } = props.res;
      letterStatuses.forEach((status, index) => {
        const accuracy = status.accuracy;
        if (inputRefs[currentRow][index] && inputRefs[currentRow][index].current) {
          const gridCell = inputRefs[currentRow][index].current;

          if (gridCell) {
            // Add a delay to the animation based on the index of the cell
            gridCell.style.animationDelay = `${index * 0.3}s`;

            gridCell.classList.add("flip");
            gridCell.addEventListener(
                "animationend",
                () => {
                  gridCell.classList.remove("flip");

                  // Move the color change into the animationend event listener
                  if (accuracy == Accuracy.Correct) {
                    gridCell.style.backgroundColor = "#4ea64e";
                  } else if (accuracy == Accuracy.Misplaced) {
                    gridCell.style.backgroundColor = "#a4a42e";
                  } else {
                    gridCell.style.backgroundColor = "darkgrey";
                  }
                },
                { once: true }
            );
          }
        }
      });
    }
  };

  /**
   * Handles the input event for a grid cell.
   * @param event The input event.
   * @param rowIndex The row index of the grid cell.
   * @param colIndex The column index of the grid cell.
   */
  const handleInput = (
      event: React.KeyboardEvent<HTMLInputElement>,
      rowIndex: number,
      colIndex: number
  ) => {
    const inputElement = event.currentTarget;

    if (/^[A-Z]$/i.test(inputElement.value)) {
      inputElement.value = inputElement.value.toUpperCase();
      inputElement.classList.add("letter-enter");
      inputElement.addEventListener(
          "animationend",
          () => {
            inputElement.classList.remove("letter-enter");
          },
          { once: true }
      );
      if (colIndex < 4) {
        inputRefs[rowIndex][colIndex + 1].current?.focus();
        setCurrentCell(colIndex+1);
        setCurrentRow(rowIndex);
      }
    } else {
      inputElement.value = "";
    }
  };


  /**
   * Handle the keydown event
   @param event The input event.
   @param rowIndex The row index of the grid cell.
   @param colIndex The column index of the grid cell.
   */
  const handleKeyDown = (
      event: React.KeyboardEvent,
      rowIndex: number,
      colIndex: number
  ) => {
    if (
        event.key === "Enter" &&
        inputRefs[rowIndex][colIndex].current!.value !== ""
    ) {
      if (colIndex === props.wordLength - 1) {
        // check if the word is valid

        props.submitGuess(
            inputRefs[rowIndex].map((ref) => ref.current!.value).join("")
        );

        console.log(props.res.isValid);
        if (rowIndex < inputRefs.length-1) {
          setCurrentRow(rowIndex);
          updateFocus(rowIndex + 1, 0);
        } else if (rowIndex === 5 && currentCell ===4 && event.key === "Enter") {
          if (props.isGameEnd) {
            if(props.res.isCorrectWord){
              alert("you won")
            }
            else{
              //


            }
            //   disable the cursor
            setGameOver(true);
            setCurrentRow(rowIndex);
          }

        }else {
          setDisableBackspace(true);
        }
      }
    }
    if (event.key === "Backspace" && colIndex > 0 && colIndex < 5) {
      inputRefs[rowIndex][colIndex].current!.value = "";
      inputRefs[rowIndex][colIndex].current?.focus();
      inputRefs[rowIndex][colIndex - 1].current?.focus();
    } else if (event.key === "Backspace" && colIndex === 5) {
      event.preventDefault();
      inputRefs[rowIndex][colIndex].current!.value = "";
      inputRefs[rowIndex][colIndex - 1].current?.focus();
    }

    // prevent the default behavior for the arrow keys to avoid
    // user from changing inputs not in the currentrow using the arrow keys
    if (
        event.key === "ArrowLeft" ||
        event.key === "ArrowRight" ||
        event.key === "ArrowUp" ||
        event.key === "ArrowDown"
    ) {
      event.preventDefault();
    }
  };

  const updateFocus = (rowIndex: number, colIndex: number) => {
    inputRefs[rowIndex][colIndex].current?.focus();
  };


  return (
      <Row>
        <div className="grid-container">
          {inputRefs.map((row, rowIndex) => (
              <div className="grid-row" key={rowIndex}>

                {row.map((ref, colIndex) => (
                    <input
                        ref={ref}
                        className={`grid-cell ${rowIndex === currentRow && colIndex === currentCell ? 'current-cell' : ''}`}
                        maxLength={1}
                        key={colIndex}
                        onInput={(event) =>
                            handleInput(event as any, rowIndex, colIndex)
                        }
                        onKeyDown={(event) => handleKeyDown(event, rowIndex, colIndex)}
                        onChange={(event) => {
                          const letter = event.target.value.toUpperCase();
                          if (!/^[A-Z]$/.test(letter)) {
                            event.target.value = "";
                          }
                        }}
                        disabled={gameOver}
                    />
                ))}
              </div>
          ))}
        </div>
      </Row>
  );
}
