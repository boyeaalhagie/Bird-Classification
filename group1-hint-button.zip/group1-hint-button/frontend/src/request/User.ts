export interface User {
    getUserId(): string;
    getDisplayName(): string;
}

export class NamedUser implements User {
    private type: string = "NamedUser";
    username: string;

    constructor(username: string) {
        this.username = username;
    }

    getDisplayName(): string {
        return this.username;
    }

    getUserId(): string {
        return this.username;
    }
}

export class Guest implements User {
    private type: string = "Guest";
    uuid: string;

    constructor(uuid: string) {
        this.uuid = uuid;
    }

    getDisplayName(): string {
        return "Guest";
    }

    getUserId(): string {
        return this.uuid;
    }
}