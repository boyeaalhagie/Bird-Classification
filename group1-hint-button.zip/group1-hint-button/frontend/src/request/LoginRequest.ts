export class LoginRequest {
    public isGuest: boolean;
    public username?: string;

    constructor(isGuest: boolean, username?: string) {
        this.isGuest = isGuest;
        this.username = username;
    }
}