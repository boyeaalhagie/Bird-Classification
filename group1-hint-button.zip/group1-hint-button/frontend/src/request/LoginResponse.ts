import {User} from "./User";

export class LoginResponse {
    public success: boolean;
    public user?: User;

    /**
     * @deprecated This constructor should not be used.
     */
    constructor() {
        this.success = false;
    }
}