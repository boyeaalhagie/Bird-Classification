import {LetterStatus} from "./LetterStatus";

export class InitGameResponse {
    public wordLength: number;
    public prevGuesses: Array<ValidGuess>;

    /**
     * @deprecated This constructor should not be used.
     */
    constructor() {
        this.wordLength = -1;
        this.prevGuesses = []
    }
}

export class ValidGuess {
    public length: number;
    public letters: Array<LetterStatus>;

    /**
     * @deprecated This constructor should not be used.
     */
    constructor() {
        this.length = -1;
        this.letters = [];
    }
}