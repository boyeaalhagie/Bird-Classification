import {User} from "./User";

export class BaseRequest {
    constructor(user: User) {
        this.user = user;
    }
    public user: User;
}