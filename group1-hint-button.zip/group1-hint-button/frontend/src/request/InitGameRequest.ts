import {BaseRequest} from "./BaseRequest";

export class InitGameRequest extends BaseRequest {

}